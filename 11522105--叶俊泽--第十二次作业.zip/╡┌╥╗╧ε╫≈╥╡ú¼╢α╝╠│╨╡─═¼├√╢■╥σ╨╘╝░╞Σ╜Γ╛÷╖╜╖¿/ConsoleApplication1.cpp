﻿#include <iostream>
#include <string>
using namespace std;
class A 
{
	int i;
protected:
	char c;
public:
	string s;
	A(int x1,char x2,string x3):i(x1),c(x2),s(x3){}

	void show() { cout << "A::i=" << i << "  A::c=" << c << "  A::s=" << s << endl; }
};


class B 
{
	int i;
protected:
	char c;
public:
	string s;
	B(int x1, char x2,string x3) :i(x1), c(x2), s(x3){}


	void show() { cout << "B::i=" << i << "  B::c=" << c << "  B::s=" << s << endl; }
};


class C : public A, public B 
{
public:
	C(int tempai, char tempac, string tempas, int tempbi, char tempbc, string tempbs) :A(tempai, tempac, tempas), B(tempbi, tempbc, tempbs) {}
	void show() {
		A::show(), // 明确指定使用基类 A 的 show函数
			B::show();// 明确指定使用基类 B 的 show函数
	}
};


int main() 
{

	C c(1, 'a', "as", 2, 'b', "bs"); 
	c.show(); 
	cout << endl;
	c.A::show();  c.B::show();

}