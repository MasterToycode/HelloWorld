#include <iostream>
#include <string>
using namespace std;

class Student 
{
protected:
    int No;
    string Name;
    char Gender;
    string ProClass;

public:
    // ���캯��
    Student(int no, const string& name, char gender, const string& proClass)
        : No(no), Name(name), Gender(gender), ProClass(proClass) {}

    // ��Ա����
    void SelectCourse() 
    {
        cout << "ѧ��ѡ��γ�" << endl;
    }

    void Study() 
    {
        cout << "ѧ���Ͽ�" << endl;
    }

    void TakeAnExam() 
    {
        cout << "ѧ���μӿ���" << endl;
    }

    void Training() 
    {
        cout << "ѧ���μ��˶�" << endl;
    }

    void Rest() 
    {
        cout << "ѧ����Ϣ" << endl;
    }

    void show() 
    {
        cout << "This student's information is following: "<<endl
            << "Student::No= " << No << endl
            << "Student::Name= " << Name << endl
            << "Student::Gender= " << Gender << endl
            << "Student::Proclass= " << ProClass << endl;
    }
};




class Master : public Student 
{
protected:
    int ExperimentNum;

public:
    // ���캯��
    Master(int no, const string& name, char gender, const string& proClass, int experimentNum)
        : Student(no, name, gender, proClass), ExperimentNum(experimentNum) {}

    // ��Ա����
    void ShowExperimentNum() 
    {
        cout << "ʵ�������" << ExperimentNum << endl;
    }


    void show() 
    {
        Student::show();
    }

};





class Doctor : public Master 
{
protected:
    int PaperNum;

public:
    // ���캯��
    Doctor(int no, const string& name, char gender, const string& proClass, int experimentNum, int paperNum)
        : Master(no, name, gender, proClass, experimentNum), PaperNum(paperNum) {}

    // ��Ա����
    void ShowPaperNum() 
    {
        cout << "����������" << PaperNum << endl;
    }


    void show() 
    {
        Student::show();
    }
};

