﻿#include"Student123.h"

int main() 
{
    // 创建学生对象
    Student student(1, "小明", 'M', "计算机科学");

    // 创建硕士研究生对象
    Master master(2, "小红", 'F', "人工智能", 5);

    // 创建博士研究生对象
    Doctor doctor(3, "小李", 'M', "大数据", 10, 3);

    // 调用学生对象的成员函数
    student.SelectCourse();
    student.Study();
    student.TakeAnExam();
    student.Training();
    student.Rest();
    student.show();

    cout << endl;

    // 调用硕士研究生对象的成员函数和新增的函数
    master.SelectCourse();
    master.Study();
    master.TakeAnExam();
    master.Training();
    master.Rest();
    master.ShowExperimentNum();
    master.show();

    cout << endl;

    // 调用博士研究生对象的成员函数和新增的函数
    doctor.SelectCourse();
    doctor.Study();
    doctor.TakeAnExam();
    doctor.Training();
    doctor.Rest();
    doctor.ShowExperimentNum();
    doctor.ShowPaperNum();
    doctor.show();

    return 0;
}

