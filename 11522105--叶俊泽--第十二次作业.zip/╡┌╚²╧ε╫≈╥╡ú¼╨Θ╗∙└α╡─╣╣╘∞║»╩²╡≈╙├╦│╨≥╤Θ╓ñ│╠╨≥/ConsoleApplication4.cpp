﻿#include<iostream>
using namespace std;
class Figure 
{
	int sidenum;
public:
	Figure():sidenum(0) {}

	Figure(int temp) :sidenum(temp) { cout << "The figure has " << sidenum << " sides." << endl; }
};




class Quadrangle1 : virtual public Figure 
{
public:
	Quadrangle1():Figure(){}
	Quadrangle1(int temp):Figure(temp) { cout << "Quadrangle1." << endl; }
};




class Parallelogram : virtual public Figure 
{
public:
	Parallelogram():Figure(){}
	Parallelogram(int temp):Figure(temp) { cout << "Parallelogram." << endl; }
};





class Quadrangle2 : virtual public Figure 
{
public:
	Quadrangle2():Figure(){}
	Quadrangle2(int temp):Figure(temp) { cout << "Quadrangle2." << endl; }
};



class Rhombus : virtual public Quadrangle1, virtual public Parallelogram 
{
protected:
	int sidelength;
public:
	Rhombus():sidelength(0){} 
	Rhombus(int t1, int t2) :Quadrangle1(t1), Parallelogram(t1), sidelength(t2)
	{
		cout << "This is a rhombus." << endl;
	}
};




class Rectangle : virtual public Quadrangle2, virtual public Parallelogram 
{
protected:
	int angle;
public:
	Rectangle() { cout << "Rectangle." << endl; }
	Rectangle(int x1,int x2):angle(x1),Quadrangle2(x2),Parallelogram(x2){}
};




class Square : public Rhombus, public Rectangle
{
public:
	Square() { cout << "Square." << endl; }
	Square(int t1, int t2, int t3) :Rhombus(t1,t2),Rectangle(t2,t3)
	{	
		cout << "The figure is a square!" << endl << "All angles of the square are " << angle << " degrees." <<
		endl << "The sidelength of the square is " << sidelength << "." << endl << "The area of the square is "
		<< sidelength * sidelength << endl; 
	
	}
};


int main() 
{
	Square s(4, 10, 90);
}
