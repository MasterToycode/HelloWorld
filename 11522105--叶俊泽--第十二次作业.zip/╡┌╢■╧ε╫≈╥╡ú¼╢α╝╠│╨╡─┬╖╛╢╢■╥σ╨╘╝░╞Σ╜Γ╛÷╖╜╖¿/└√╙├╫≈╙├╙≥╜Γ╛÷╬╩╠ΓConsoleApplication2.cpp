﻿#include <iostream>
#include <string>
using namespace std;
class A
{
	int i;
protected:
	char c;
public:
	string s;

	A(int x1, char x2, string x3) :i(x1), c(x2), s(x3) {}

	void show() { cout << "A::i= " << i << " A::c= " << c << " A::s= " << s << endl; }
};



class B : public A 
{
public:
	B(int tempi, char tempc, string temps) : A(tempi,tempc,temps){}
};




class C : public A 
{
public:
	C(int tempi, char tempc, string temps) : A(tempi, tempc, temps) {}
};




class D : public B, public C 
{
public:
	D(int tempai, char tempac, string tempas, int tempbi, char tempbc, string tempbs) :B(tempai, tempac, tempas), C(tempbi, tempbc, tempbs) {}

	void show() {
		B::show();
		C::show();
	}
};


int main() 
{
	D d(98, 'b', "bs", 99, 'c', "cs");
	d.show();
	cout << endl;
	d.B::show();
	cout << endl;
	d.C::show();
	cout << endl;
	cout << "使用作用域规则解决路径二义性时，派生类对象所占空间大小为：" << sizeof(d) << endl;
}
