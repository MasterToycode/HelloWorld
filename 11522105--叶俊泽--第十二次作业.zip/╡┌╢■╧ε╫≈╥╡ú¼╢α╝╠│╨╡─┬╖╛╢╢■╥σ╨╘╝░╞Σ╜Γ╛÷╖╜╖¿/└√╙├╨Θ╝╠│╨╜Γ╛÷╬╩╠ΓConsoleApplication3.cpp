﻿#include <iostream>
#include <string>
using namespace std;


class A
{
	int i;
protected:
	char c;
public:
	string s;
	A() : i(0), c('\0'), s("") {}

	A(int x1, char x2, string x3) :i(x1), c(x2), s(x3) {}

	void show() { cout << "A::i= " << i << " A::c= " << c << " A::s= " << s << endl; }
};



class B : public virtual A
{
public:
	B(int tempi, char tempc, string temps) : A(tempi, tempc, temps) {}
};




class C : public virtual A
{
public:
	C(int tempi, char tempc, string temps) : A(tempi, tempc, temps) {}
};




class D : public  B, public  C
{
public:
	D(int tempai, char tempac, string tempas, int tempbi, char tempbc, string tempbs)
		:  B(tempbi, tempbc, tempbs), C(tempai, tempac, tempas) , A(tempai, tempac, tempas) {}
	
	void show() 
	{
		B::show();
		C::show();
	}
};


int main()
{
	D d(97, 'b', "bs", 91, 'c', "cs");
	d.show();
	cout << endl;
	d.B::show();
	cout << endl;
	d.C::show();
	cout << endl;
	cout << "使用虚继承规则解决路径二义性时，派生类对象所占空间大小为：" << sizeof(d) << endl;
}
