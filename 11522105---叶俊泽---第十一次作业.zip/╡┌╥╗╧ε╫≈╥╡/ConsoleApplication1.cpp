﻿#include"No1.h"
int main()
{
    GrandFather grandFather("GF", 70, 123);
    Father father("F", 45, 456, "GF", 70, 123);
    Child child("C", 18, 789, "F", 45, 456, "GF", 70, 123);

    grandFather.showName();
    grandFather.showAge();
    grandFather.showCardID();

    father.showName();
    father.showAge();
    father.showCardID();

    child.showName();
    child.showAge();
    child.showCardID();
    return 0;
}

/*
最近优先原则（Most Recently Declared）是指在继承链中，
如果派生类中声明了与基类相同名称的函数，那么在派生类对象上调用该函数时，将优先调用派生类中的函数，
而不考虑基类是否有相同名称的函数。这是因为在派生类中重新声明的函数会覆盖基类中相同名称的函数。
*/