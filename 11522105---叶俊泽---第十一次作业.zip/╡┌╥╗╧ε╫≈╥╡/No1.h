#include<iostream>
#include<string>
using namespace std;
class GrandFather 
{
protected:
	int Age;
	int  CardID;
	string Name;

public:
	GrandFather(string name, int age, int cardid):Name(name),Age(age),CardID(cardid)
	{
	}

	void showName() 
	{
		cout << "GrandFather::Name=" << Name << endl;
	}

	void showAge()
	{
		cout << "GrandFather::Age=" << Age << endl;
	}

	void showCardID()
	{
		cout << "GrandFather::CardID=" << CardID << endl;
	}
	
};



class Father :public GrandFather 
{
protected:
	int Age;
	int  CardID;
	string Name;

public:
	Father(string name, int age, int cardid, string name1, int age1, int cardid1) :GrandFather(name1, age1, cardid1), Name(name), Age(age), CardID(cardid)
	{
	}
	void showName() { cout << "Father::Name=" << Name << endl; }
	void showAge() { cout << "Father::Age=" << Age << endl; }
	void showCardID() { cout << "Father::CardID=" << CardID << endl; }
	         
};




class Child :public Father 
{
protected:
	int Age;
	int  CardID;
	string Name;

public:
	Child(string name, int age, int cardid, string name1, int age1, int cardid1, string name2, int age2, int cardid2) :Father(name1, age1, cardid1,name2,age2,cardid2), Name(name), Age(age), CardID(cardid)
	{
	}
	void showName() { cout << "Child::Name=" << Name << endl; }
	void showAge() { cout << "Child::Age=" << Age << endl; }
	void showCardID() { cout << "Child::CardID=" << CardID << endl; }

	
};

