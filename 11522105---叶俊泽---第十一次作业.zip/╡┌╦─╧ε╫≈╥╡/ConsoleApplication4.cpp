﻿#include"No4.h"
int main()
{
    // 定义战士的生命值和名字
    const int warriorValues[] = { 20, 30, 40, 50, 60 };
    const string warriorNames[] = { "dragon", "ninja", "iceman", "lion", "wolf" };

    // 定义总部的名字
    const string headquarterNames[] = { "Red", "Blue" };

    // 定义总部生命值
    const int redLifeValue = 100;
    const int blueLifeValue = 120;

    // 定义战士出生顺序
    const int order[] = { 2, 4, 1, 3, 0 }; 

    // 创建红色总部和蓝色总部
    headquarters redHeadquarter(redLifeValue, 0, warriorValues, warriorNames, order, headquarterNames);
    headquarters blueHeadquarter(blueLifeValue, 1, warriorValues, warriorNames, order, headquarterNames);

    // 模拟多个回合的战士生产过程
    for (int time = 1; time <= 5; ++time)
    {
        redHeadquarter.product(time, order[time - 1]);
        blueHeadquarter.product(time, order[time - 1]);
    }

    return 0;
}
