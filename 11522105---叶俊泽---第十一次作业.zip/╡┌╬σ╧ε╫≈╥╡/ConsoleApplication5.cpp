﻿#include"No5.h"
int main() 
{
	SofaBed test(40, 20, 4, 100, 60, 30, 2, 150);
}