#include<iostream>
#include<Windows.h>
using namespace std;
class Date 
{
protected:
	int Year, Month, Day;
public:
	Date(int y = 0, int m = 0, int d = 0) : Year(y), Month(m), Day(d) {}

	void SetTime(int h, int m, int s) { Year = h; Month = m; Day = s; }
	void ShowDate() 
	{
		cout << "Now is " << Year << "�� " << Month << "�� " << Day << "�� ";
	};
};




class Time 
{
protected:
	int Hour, Minute, Second;
public:
	Time(int h = 0, int m = 0, int s = 0) { Hour = h; Minute = m; Second = s; }
	void SetTime(int h, int m, int s) { Hour = h; Minute = m; Second = s; }
	void ShowTime() 
	{ 
		cout<< Hour<<"ʱ "<< Minute << "�� "<< Second<<"�� "<<endl;
	}
};



class DateTime : public Date, public Time 
{
public:
	DateTime(int y = 0, int mon = 0, int d = 0, int h = 0, int min = 0, int s = 0) :Date(y,mon,d),Time(h,min)
	{ ShowDateTime(); }
	void SetDateTime(int h1, int m1, int s1, int h, int m, int s) 
	{
		Hour = h; Minute = m; Second = s;
		Year = h1; Month = m1; Day = s1;
	}

	void ShowDateTime() 
	{
		Date::ShowDate();
		Time::ShowTime();
	}
};
