﻿#include"No6.h"
int main() 
{
	SYSTEMTIME sys;
	GetLocalTime(&sys);
	DateTime dt(sys.wYear, sys.wMonth, sys.wDay, sys.wHour, sys.wMinute, sys.wSecond);
	char flag = 'y';
	cout << "是否需要修改日期和时间？(y/n)";
	cin >> flag;
	int h1 = 0;
	int m1 = 0;
	int s1 = 0;
	int h = 0;
	int m = 0;
	int s = 0;
	while (tolower(flag) == 'y') 
	{
		cout << "请输入新的日期和时间：" << endl;
		cout << "Year:"; cin >> h1; cout << endl;
		cout << "Month:"; cin >> m1; cout << endl;
		cout << "Day:"; cin >> s1; cout << endl;
		cout << "Hour:"; cin >> h; cout << endl;
		cout << "minute:"; cin >> m; cout << endl;
		cout << "second:"; cin >> s; cout << endl;
		dt.SetDateTime(h1, m1, s1, h, m, s);
		dt.ShowDateTime();
		cout << "------------------------------------------" << endl;
		cout << "是否继续修改日期和时间?(y/n)";
		cin >> flag;
	}

}