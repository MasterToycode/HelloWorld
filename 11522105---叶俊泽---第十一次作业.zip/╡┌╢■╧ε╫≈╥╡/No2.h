#include<iostream>
using namespace std;
class Base 
{
protected:
	int x;
	int y;
	int z;
public:
	Base(int t1, int t2, int t3) :x(t1), y(t2), z(t3) {}
	void showxyz() { cout << "Base::x=" << x << "  Base::y=" << y << "  Base::z=" << z << endl; }
};


class Derive :public Base 
{
protected:
	int dx;
	int dy;
	int dz;
public:
	Derive(int t1, int t2, int t3,int t4, int t5, int t6):Base(t1,t2,t3),dx(t4),dy(t5),dz(t6){}
	void showxyz() 
	{
		cout << "Base::x=" << x 
			<< "  Base::y=" << y 
			<< "  Base::z=" << z 
			<<" Derive::dx="<<dx
			<< " Derive::dy=" << dy
			<< " Derive::dz=" << dz
			<< endl;
	}
};

